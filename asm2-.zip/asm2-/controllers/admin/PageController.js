exports.homePage = (req,res,next)=>{
  res.render("admin/home")
}



exports.loginPage = (req,res,next)=>{
  res.render("admin/login")
}
